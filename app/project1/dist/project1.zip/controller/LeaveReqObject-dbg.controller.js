// ✅ FIXED: UploadSet file content issue in table mode

sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/ui/model/json/JSONModel"
], function (Controller, MessageToast, JSONModel) {
    "use strict";

    async function getFileContentFromUploadSet(fileName, aFilesFromModel) {
        for (const fileEntry of aFilesFromModel) {
            if (fileEntry.fileName === fileName && fileEntry.fileObject) {
                return await fileEntry.fileObject.arrayBuffer(); // ✅ binary
            }
        }
        return null;
    }


    return Controller.extend("project1.controller.LeaveReqObject", {
        onInit: function () {
            const oDocModel = new JSONModel({ items: [] });
            this.getView().setModel(oDocModel, "documents");
        },

        onBeforeUploadStarts: async function (oEvent) {
            const oItem = oEvent.getParameter("item");
            const oFile = await oItem.getFileObject?.();
        
            if (!oFile) {
                MessageToast.show("No file selected.");
                return;
            }
        
            const base64 = await this.fileToBase64(oFile); // ✅ convert content
        
            const oModel = this.getView().getModel("documents");
            const aItems = oModel.getProperty("/items") || [];
        
            aItems.push({
                fileName: oFile.name,
                mediaType: oFile.type,
                fileSize: oFile.size,
                fileObject: oFile,
                content: base64,     // ✅ THIS is what was missing earlier
                ID: null             // Will be filled later after backend save
            });
        
            oModel.setProperty("/items", aItems);
            oEvent.preventDefault(); // ✅ prevent native upload
            MessageToast.show("File stored locally.");
        },
        

         fileToBase64(file) {
            return new Promise((resolve, reject) => {
              const reader = new FileReader();
              reader.onload = () => {
                const base64 = reader.result.split(",")[1]; // remove "data:*/*;base64,"
                resolve(base64);
              };
              reader.onerror = reject;
              reader.readAsDataURL(file);
            });
          },
          


        onCreate: async function () {
            debugger


            const oView = this.getView();
            const oModel = this.getOwnerComponent().getModel();
            const baseUrl = oModel.getServiceUrl();

            const employeeName = oView.byId("inputEmployeeName").getValue();
            const leaveType = oView.byId("inputLeaveType").getSelectedItem()?.getText();
            const startDate = oView.byId("inputStartDate").getValue();
            const endDate = oView.byId("inputEndDate").getValue();
            const reason = oView.byId("inputReason").getValue();
            const status = oView.byId("inputStatus").getValue() || "Pending";

            if (!employeeName || !leaveType || !startDate || !endDate) {
                MessageToast.show("Please fill in all required fields.");
                return;
            }

            const oDocModel = oView.getModel("documents");
            const aFiles = oDocModel.getProperty("/items") || [];
            const fileMeta = aFiles[0];

            if (!fileMeta || !fileMeta.fileObject) {
                MessageToast.show("File content missing. Please upload again.");
                return;
            }

            try {
                const oFunction = oModel.bindContext("/addLeaveRequest(...)");
                oFunction
                    .setParameter("employeeName", employeeName)
                    .setParameter("leaveType", leaveType)
                    .setParameter("startDate", startDate)
                    .setParameter("endDate", endDate)
                    .setParameter("reason", reason)
                    .setParameter("status", status);

                await oFunction.execute();
                const result = await oFunction.getBoundContext().requestObject();
                const leaveID = result.ID;

                const fileMeta = aFiles[0];
                const base64Content = await this.fileToBase64(fileMeta.fileObject); // ✅ fixed call

                
                const addFileFn = oModel.bindContext("/addFileToLeave(...)");
                
                addFileFn.setParameter("leaveID", leaveID);
                addFileFn.setParameter("fileName", fileMeta.fileName);
                addFileFn.setParameter("mediaType", fileMeta.mediaType);
                addFileFn.setParameter("size", fileMeta.fileSize);
                addFileFn.setParameter("content", base64Content); // ✅ base64 string
                
                await addFileFn.execute();

                // const fileResult = await addFile.getBoundContext().requestObject();
                // const fileID = fileResult.value;

                // const content = await getFileContentFromUploadSet(fileMeta.fileName, aFiles);
                // if (!content) {
                //     MessageToast.show("File content missing. Upload failed.");
                //     return;
                // }
                // const url = ${baseUrl}LeaveRequest(ID=${leaveID},IsActiveEntity=true)/files;
                // await fetch(`${baseUrl}/LeaveRequest(ID=${leaveID},IsActiveEntity=true)/files(ID=${fileID},IsActiveEntity=true)/content`, {
                //     method: "PUT",
                //     headers: {
                //         "Content-Type": fileMeta.mediaType
                //     },
                //     body: content
                // });
                // const uploadUrl = `${baseUrl}Files(ID=${fileID},IsActiveEntity=false)/content`;

                // await fetch(uploadUrl, {
                //     method: "PUT",
                //     headers: {
                //         "Content-Type": fileMeta.mediaType
                //     },
                //     body: content  // must be ArrayBuffer or Blob
                // });


                MessageToast.show("Leave request submitted with file.");
                this.onCancel();
            } catch (error) {
                console.error("Upload failed:", error);
                MessageToast.show("Leave request failed.");
            }
        },

        onCancel: function () {
            this.getOwnerComponent().getRouter().navTo("RouteView1");
        },




        openPreview: async function (oEvent) {
            debugger
            const oContext = oEvent.getSource().getBindingContext("documents");
            const oDocData = oContext.getObject();
            const base64 = oDocData.content;
            const fileName = oDocData.fileName;
            const mediaType = oDocData.mediaType || "application/octet-stream";
        
            // Case 1: Preview from local model (unsaved)
            if (base64) {
                const byteCharacters = atob(base64);
                const byteNumbers = new Array(byteCharacters.length);
                for (let i = 0; i < byteCharacters.length; i++) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                const byteArray = new Uint8Array(byteNumbers);
                const blob = new Blob([byteArray], { type: mediaType });
        
                const url = URL.createObjectURL(blob);
                window.open(url, "_blank");
                return;
            }
        
            // Case 2: Preview from backend (already saved to DB)
            const fileID = oDocData.ID; // ensure this is populated during upload (if saved)
            if (!fileID) {
                MessageToast.show("File not yet saved. Please submit first.");
                return;
            }
        
            try {
                const oModel = this.getView().getModel();
                const baseUrl = oModel.getServiceUrl();
                const response = await fetch(`${baseUrl}Files(ID=${fileID},IsActiveEntity=true)`);
                const fileData = await response.json();
        
                if (!fileData.content) {
                    MessageToast.show("No content found in database.");
                    return;
                }
        
                const backendBase64 = fileData.content;
                const backendMediaType = fileData.mediaType || "application/octet-stream";
        
                const byteCharacters = atob(backendBase64);
                const byteNumbers = new Array(byteCharacters.length);
                for (let i = 0; i < byteCharacters.length; i++) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                const byteArray = new Uint8Array(byteNumbers);
                const blob = new Blob([byteArray], { type: backendMediaType });
        
                const url = URL.createObjectURL(blob);
                window.open(url, "_blank");
            } catch (error) {
                console.error("Preview failed:", error);
                MessageToast.show("Failed to load preview.");
            }
        }
        
        
    });
});
